
import { Link } from 'react-router-dom';

export default function Navbar() {
  return (
    <nav className="bg-black text-white px-6 py-4 flex justify-between items-center">
      <div className="text-xl font-bold">🏇 HorseRaceNFT</div>
      <div className="space-x-4">
        <Link to="/" className="hover:underline">Home</Link>
        <Link to="/mint" className="hover:underline">Mint</Link>
        <Link to="/stable" className="hover:underline">Your Stable</Link>
        <Link to="/race-centre" className="hover:underline">Race Centre</Link>
        <Link to="/about" className="hover:underline">About</Link>
      </div>
      <div className="text-sm text-right">
        <button className="bg-green-600 px-4 py-1 rounded">Connect Wallet</button>
        <div className="text-xs mt-1">Floor: 0.03 SOL | Prize Pot: 150 SOL | Next Race: Sat 3PM</div>
      </div>
    </nav>
  );
}
