
export default function RaceCentre() {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Race Centre</h2>
      <p>Next race: Saturday 3PM — Prize Pool: 150 SOL</p>
      <ul className="list-disc ml-6 mt-4">
        <li>Race History (coming soon)</li>
        <li>Future Fixtures</li>
        <li>Leaderboard</li>
      </ul>
    </div>
  );
}
