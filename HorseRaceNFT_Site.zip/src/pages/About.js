
export default function About() {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">About the Project</h2>
      <p>This project builds on the community spirit of the Lazy Horse Race Club, giving new life and real value back to original holders — and creating a whole new gamified experience for all participants.</p>
    </div>
  );
}
