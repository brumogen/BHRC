
export default function Mint() {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Mint Your Horse</h2>
      <p className="mb-2">Connect your wallet to mint a new NFT horse. Mint price: 0.03 SOL</p>
      <button className="bg-blue-600 text-white px-6 py-2 rounded mt-4">Connect Wallet (coming soon)</button>
    </div>
  );
}
