
export default function Home() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-4">Welcome to HorseRaceNFT</h1>
      <p className="mb-4">The next-generation NFT horse racing experience. Breed, race, and win real prizes.</p>
      <ul className="list-disc ml-6">
        <li>🏁 Weekly races</li>
        <li>🐎 Breeding and trading</li>
        <li>💰 Real prize pools</li>
        <li>📈 Leaderboards and rewards</li>
      </ul>
    </div>
  );
}
