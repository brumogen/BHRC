
export default function Stable() {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Your Stable</h2>
      <p>This page will show your owned horses, their condition, race history, and winnings.</p>
      <p className="italic mt-2">Connect wallet to view your stable (feature coming soon).</p>
    </div>
  );
}
